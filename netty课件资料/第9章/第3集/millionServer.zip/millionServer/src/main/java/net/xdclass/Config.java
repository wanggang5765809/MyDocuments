package net.xdclass;

public class Config {

    public static final int BEGIN_PORT = 8000;

    public static final int END_PORT = 8050;

}
