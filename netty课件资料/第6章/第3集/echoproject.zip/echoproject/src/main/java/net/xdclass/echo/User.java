package net.xdclass.echo;

import java.io.Serializable;

public class User implements Serializable {

    private int age;
    private String name;


}
